
can_breathe = True
life_rules = {"Money": ["Work", "Self pity"],
              "Health": ["Sport”, “Alcohol"],
              "love": ["Self Acceptance", "depression"],
              "Goal": ["Learning", "Make plans"],
              "Dream": ["Chilling", "Cloud the mind"],
              "Self Delusion": [None, "Be afraid"],
              "Life For Fan": ["Life of learning and love"],
              }


while can_breathe:
    for life_desigion in life_rules:
        for i in range(len(breathe)):
            life = input("Chose:")
